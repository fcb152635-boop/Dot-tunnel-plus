package com.dot.tunnelplus

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.graphics.Typeface
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

class MainActivity : Activity() {
    private val bg = Color.rgb(10, 10, 10)
    private val panel = Color.rgb(25, 25, 25)
    private val red = Color.rgb(255, 48, 48)
    private val white = Color.WHITE
    private val muted = Color.rgb(170, 170, 170)
    private var connected = false
    private var selectedServer = "مصر • القاهرة"
    private lateinit var status: TextView
    private lateinit var connect: Button
    private lateinit var chosen: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg
        window.navigationBarColor = bg
        window.decorView.systemUiVisibility = 0

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(bg)
            setPadding(dp(18), dp(18), dp(18), dp(12))
        }
        val scroll = ScrollView(this)
        val content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        scroll.addView(content)

        content.addView(label("DOT", 34, red, true, Gravity.CENTER))
        content.addView(label("TUNNEL PLUS", 17, white, true, Gravity.CENTER))
        content.addView(label("سيرفرات مصرية وعالمية", 14, muted, false, Gravity.CENTER).also { it.setPadding(0, dp(4), 0, dp(18)) })

        val statusCard = card()
        status = label("غير متصل", 18, white, true, Gravity.CENTER)
        statusCard.addView(status)
        statusCard.addView(label("اختر سيرفرًا ثم اضغط اتصال", 13, muted, false, Gravity.CENTER).apply { setPadding(0, dp(8), 0, dp(12)) })
        connect = Button(this).apply {
            text = "اتصال"
            setTextColor(white)
            setBackgroundColor(red)
            textSize = 17f
            setOnClickListener {
                connected = !connected
                // UI prototype only: no VPN backend/server is configured yet.
                status.text = if (connected) "تم تفعيل وضع العرض (ليس اتصال VPN)" else "غير متصل"
                text = if (connected) "فصل" else "اتصال"
                setBackgroundColor(if (connected) Color.DKGRAY else red)
            }
        }
        statusCard.addView(connect, LinearLayout.LayoutParams(-1, dp(52)))
        content.addView(statusCard)

        content.addView(section("السيرفر المختار"))
        chosen = label(selectedServer, 16, white, true, Gravity.CENTER_VERTICAL)
        val selectedCard = card()
        selectedCard.addView(chosen)
        content.addView(selectedCard)

        content.addView(section("السيرفرات"))
        val servers = listOf(
            "🇪🇬 مصر • القاهرة", "🇪🇬 مصر • الإسكندرية", "🇩🇪 ألمانيا • فرانكفورت",
            "🇳🇱 هولندا • أمستردام", "🇫🇷 فرنسا • باريس", "🇬🇧 بريطانيا • لندن",
            "🇺🇸 الولايات المتحدة • نيويورك", "🇸🇬 سنغافورة • سنغافورة", "🇹🇷 تركيا • إسطنبول"
        )
        servers.forEach { server ->
            val row = card()
            val button = Button(this).apply {
                text = "اختيار"
                textSize = 12f
                setTextColor(white)
                setBackgroundColor(Color.rgb(65, 20, 20))
                setOnClickListener {
                    selectedServer = server
                    chosen.text = server
                }
            }
            row.orientation = LinearLayout.HORIZONTAL
            val name = label(server, 15, white, false, Gravity.CENTER_VERTICAL)
            row.addView(name, LinearLayout.LayoutParams(0, dp(48), 1f))
            row.addView(button, LinearLayout.LayoutParams(dp(92), dp(44)))
            content.addView(row)
        }
        content.addView(label("تنبيه: هذه قائمة واجهة تجريبية. لم تُضف خوادم حقيقية بعد.", 12, muted, false, Gravity.CENTER).apply {
            setPadding(dp(4), dp(16), dp(4), dp(12))
        })
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        root.addView(label("الرئيسية     •     السيرفرات     •     الإحصائيات", 12, muted, false, Gravity.CENTER).apply {
            setPadding(0, dp(12), 0, dp(4))
        })
        setContentView(root)
    }

    private fun card(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(14), dp(12), dp(14), dp(12))
        setBackgroundColor(panel)
        val lp = LinearLayout.LayoutParams(-1, LinearLayout.LayoutParams.WRAP_CONTENT)
        lp.setMargins(0, dp(6), 0, dp(6))
        layoutParams = lp
    }

    private fun section(text: String): TextView =
        label(text, 16, red, true, Gravity.CENTER_VERTICAL).apply {
            setPadding(dp(2), dp(14), 0, dp(2))
        }

    private fun label(text: String, size: Int, color: Int, bold: Boolean, gravity: Int): TextView =
        TextView(this).apply {
            this.text = text
            textSize = size.toFloat()
            setTextColor(color)
            this.gravity = gravity
            if (bold) typeface = Typeface.DEFAULT_BOLD
        }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()
}
