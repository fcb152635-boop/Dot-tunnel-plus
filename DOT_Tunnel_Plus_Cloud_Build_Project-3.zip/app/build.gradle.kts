plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.dot.tunnelplus"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.dot.tunnelplus"
        minSdk = 26
        targetSdk = 35
        versionCode = 1
        versionName = "0.1.0"
    }
}
